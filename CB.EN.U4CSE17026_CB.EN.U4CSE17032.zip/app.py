from flask import Flask, render_template,redirect,request, url_for

from flask_mysqldb import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'

app.config['MYSQL_DB'] = 'MyDB'

mysql = MySQL(app)



@app.route('/', methods=['POST','GET'])
def mai():
    return render_template('index.html')


@app.route('/signup', methods=['POST','GET'])
def index():
    if request.method == "POST":
        details = request.form
        firstName = details['fname']
        password = details['password']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO MyUsers(firstName, password) VALUES (%s, %s)", (firstName, password))
        mysql.connection.commit()
        cur.close()
        return 'success'
    return render_template('signup.html')

@app.route('/login', methods=['POST','GET'])
def login():
    if request.method == "POST":
        details = request.form
        firstName = details['fname']
        password = details['password']
        cur = mysql.connection.cursor()
        qwe=cur.execute("SELECT * FROM MyUsers where firstname=%s AND password = %s",[firstName,password])
        if qwe == 1:
            return redirect(url_for('user'))
        else:
            return 'wrong password. Go back and try again'
    return render_template('login.html')    

@app.route('/user', methods=['POST','GET'])
def user():
    return render_template('user.html')


@app.route('/book', methods=['POST','GET'])
def book():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM car")
    data = cur.fetchall()
    return render_template('book.html', data=data)

@app.route('/success/<name>', methods=['POST','GET'])
def suc(name):
    cur = mysql.connection.cursor()
    cur.execute("delete from car where carname = %s",[name])
    mysql.connection.commit()
    cur.close()
    return "Booking Successfull"

if __name__ == '__main__':
    app.run(debug=True)